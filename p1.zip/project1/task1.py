from system_model import SystemModel
import numpy as np
import matplotlib.pyplot as plt
import control

sm = SystemModel()
sm.z = np.vstack((np.random.uniform(low=-2.0, high=2.0, size=(2,1)), np.zeros((2, 1)))) # initialize state of the system
y = sm.step(np.zeros((2, 1))) # get initial robot position

input_signal = np.ones((15000, 2))
t = np.arange(0, 15000)
t_seconds = t * 0.001

output_signal = sm.sim(input_signal)

# Using the formulae from Bode plots tau using bode plots
tau = (1/10) * (10**(1/10) - 1)**(1/2)

print(tau)

s = control.TransferFunction.s
_G = 1 / (1 + tau * s)**3
print(_G)

# #defining transfer function
# numerator = [1] #coefficient of numerator =>1
# denominator = [tau**3, 3*tau**2, 3*tau, 1]  #coefficients for denominator of transfer function => (1+tau*s)**3
# #make the transfer function with the numerator and denominator
# G = control.TransferFunction(numerator, denominator)
# print(G)

filtered_output_1 = control.forced_response(_G, T=t_seconds, U=output_signal[:, 0])
filtered_output_2 = control.forced_response(_G, T=t_seconds, U=output_signal[:, 1])

plt.plot(t, input_signal[:, 0], label='input_1')
plt.plot(t, output_signal[:, 0], label='output_1')
plt.plot(t, filtered_output_1[1], label='filtered_output_1')
plt.xlabel('Time (ms)')
plt.ylabel('Amplitude_1 (dB)')
plt.legend()
plt.show()

plt.plot(t, input_signal[:, 1], label='input_2')
plt.plot(t, output_signal[:, 1], label='output_2')
plt.plot(t, filtered_output_2[1], label='filtered_output_2')
plt.xlabel('Time (ms)')
plt.ylabel('Amplitude_2 (dB)')
plt.legend()
plt.show()